<?php
return [
    'whatsapp_number' => '573160497130',
    'domain' => 'https://tubichatlat/',
    'mail' => 'tubichatlat@gmail.com',
    'domain_app' => 'https://app.tubichatlat/',
    'domain_api' => 'https://api.tubichatlat/',
    'domain_signup' => '/Signup.php',
    'youtube' => 'https://www.youtube.com/embed/UtijXkcq3GA?si=c0CvgxjwPYZWmIzG',
    'facebook' => 'https://facebook.com',
    'twitter' => 'https://twitter.com',
    'github' => 'https://github.com',
    'moneda' => '$',
    'plan1name' => 'Inicio',
    'plan1price' => '0.00',
    'plan2name' => 'Emprendedores',
    'plan2price' => '9.99',
    'plan2priceanual' => '49.99',
    'plan3name' => 'Empresarial',
    'plan3price' => '8.99',
    'plan3priceanual' => '79.99',
    
    
    
    
    
];
?>